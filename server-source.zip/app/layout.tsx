import type { Metadata } from 'next';
import './globals.css';
export const metadata:Metadata={title:'AFTERLIGHT — A Signal Worth Saving',description:'Different clues. One shared drone. A cooperative rescue expedition for 2–6 explorers. Play together from any device.',openGraph:{title:'AFTERLIGHT — A Signal Worth Saving',description:'Different clues. One drone. A shared way home.',images:[{url:'https://afterlight-rescue-expedition.zahid23saim.chatgpt.site/cover.png',width:1600,height:900}]},icons:{icon:'/favicon.svg'}};
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="en"><body>{children}</body></html>}

