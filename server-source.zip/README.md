# AFTERLIGHT — A Signal Worth Saving

A cooperative browser game for 2–6 explorers. Every player receives a different hazard report. Together they plan and approve a shared drone route, rescue three lightkeepers, and return to the extraction beacon before the battery runs out.

## Play
Create a room, share the link or six-letter code, and have everyone join before the captain launches. Any player can edit a route of 1–3 compass moves. Each connected player must approve the current route. Editing resets approvals. The captain executes it.

Every move costs 1 charge. A blocked move costs 3 total and leaves the drone in place. Each rescue restores 3 charge. Rescue all three lightkeepers, then reach F6. There is no wall-clock timer. Flags are shared notes, not automatic obstacles.

Practice mode gives a solo player every clue and an inactive practice companion. Three missions offer increasing route complexity. Audio is optional; reduced-motion preferences are respected.

## Run locally
Requires Node >=22.13 and npm.

1. `npm ci`
2. `npm run build`
3. `node --import ./scripts/sites-env.mjs ./node_modules/wrangler/bin/wrangler.js d1 execute DB --local --config dist/server/wrangler.json --persist-to .wrangler/state --file drizzle/0000_old_lizard.sql`
4. `npm run dev`
5. Visit the printed local URL, normally http://127.0.0.1:5173.

For local verification: `node scripts/test-game.mjs` and `node node_modules/typescript/bin/tsc --noEmit`.

## Implementation
React / Vinext on Cloudflare Workers, D1 persistent room state, anonymous per-tab crew passes, compare-and-swap writes to prevent lost updates. The server validates commands, approvals, phase transitions and captain permissions. Responses contain only the caller's clues; other players' crew passes are removed. The browser refreshes room state about every 1.2 seconds, with 15-second heartbeats. Rooms expire after 24 hours. A captain absent for 45 seconds can be replaced by another player. Browser session storage allows refreshing the same tab without losing membership.

Private clue visibility is a gameplay rule, not protection against players deliberately consulting the published source or remembering a previous playthrough. The three authored maps are repeatable puzzles. Room codes are invitations: share only with intended players. Do not put personal information in callsigns or radio messages.

## Deployment
The .openai/hosting.json file identifies the existing Sites project. Reuse its project_id; do not create a duplicate. The hosting platform applies the committed Drizzle migration and provisions the DB binding. Source, build, version and deployment are managed through Sites.
